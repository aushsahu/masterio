/// Base Repository for all repositories
/// all repository should be implemented it
abstract class IBaseRepository {}
