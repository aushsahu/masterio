import 'package:flutter/material.dart';

/// [Locales] supported in app
const List<Locale> supportedLocales = [
  Locale('en', 'US'),
];
